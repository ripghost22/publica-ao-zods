
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const SERVICES_DATA = [
  { id: 1, name: "Alongamento em Acrílico Clássico", cat: "alongamento", price: 180, desc: "Estrutura moldada ultra resistente, curvatura C natural e esmaltação básica.", img: "https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=600&auto=format&fit=crop" },
  { id: 2, name: "Alongamento em Fibra de Vidro", cat: "alongamento", price: 190, desc: "Fios finos e resistentes que aderem com leveza e aspecto hiper realista.", img: "https://images.unsplash.com/photo-1632345031435-8727f6897d53?q=80&w=600&auto=format&fit=crop" },
  { id: 3, name: "Banho de Gel Fortalecedor", cat: "alongamento", price: 120, desc: "Camada protetora sobre as unhas naturais contra quebras e descamação.", img: "https://images.unsplash.com/photo-1519014816548-bf5fe059798b?q=80&w=600&auto=format&fit=crop" },
  { id: 4, name: "Esmaltação em Gel de Longa Duração", cat: "nailart", price: 90, desc: "Brilho e cor vívida intactos por até 21 dias sem lascar. Secagem em cabine LED.", img: "https://images.unsplash.com/photo-1599940824399-b87987ceb72a?q=80&w=600&auto=format&fit=crop" },
  { id: 5, name: "Francesa Reversa Encapsulada", cat: "nailart", price: 220, desc: "Técnica de leito esculpido com ponta translúcida e glitter embutido.", img: "https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=600&auto=format&fit=crop" },
  { id: 6, name: "Manutenção de Acrílico (Até 25 dias)", cat: "manutencao", price: 130, desc: "Preenchimento da raiz, nivelamento da estrutura e troca de esmalte.", img: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?q=80&w=600&auto=format&fit=crop" },
  { id: 7, name: "Manutenção de Fibra de Vidro", cat: "manutencao", price: 140, desc: "Reposição de fibra, reforço de borda livre e alinhamento milimétrico.", img: "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?q=80&w=600&auto=format&fit=crop" },
  { id: 8, name: "Manicure Russa Combinada + Cutilagem", cat: "nailart", price: 70, desc: "Cutilagem a seco com micromotor e brocas cirúrgicas de acabamento profundo.", img: "https://images.unsplash.com/photo-1632345031435-8727f6897d53?q=80&w=600&auto=format&fit=crop" },
  { id: 9, name: "Spa Completo das Mãos e Esfoliação", cat: "nailart", price: 85, desc: "Banho de parafina morna, peeling renovador e massagem relaxante.", img: "https://images.unsplash.com/photo-1519014816548-bf5fe059798b?q=80&w=600&auto=format&fit=crop" },
  { id: 10, name: "Remoção Segura de Alongamento", cat: "manutencao", price: 60, desc: "Retirada química cuidadosa com hidratação intensiva pós-procedimento.", img: "https://images.unsplash.com/photo-1599940824399-b87987ceb72a?q=80&w=600&auto=format&fit=crop" },
  { id: 11, name: "Nail Art Personalizada (Por Unha)", cat: "nailart", price: 20, desc: "Desenho à mão livre, pedrarias Swarovski, chrome flakes ou efeito mármore.", img: "https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=600&auto=format&fit=crop" }
];

const GALLERY_DATA = [
  { id: 1, cat: "acrilico encapsulada", title: "Acrílico Encapsulado Nude", img: "https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=1200&auto=format&fit=crop" },
  { id: 2, cat: "gel minimal", title: "Babyboomer Suave", img: "https://images.unsplash.com/photo-1632345031435-8727f6897d53?q=80&w=1200&auto=format&fit=crop" },
  { id: 3, cat: "nailart cores", title: "Glitter Holográfico", img: "https://images.unsplash.com/photo-1519014816548-bf5fe059798b?q=80&w=1200&auto=format&fit=crop" },
  { id: 4, cat: "gel minimal", title: "Francesinha Minimalista", img: "https://images.unsplash.com/photo-1599940824399-b87987ceb72a?q=80&w=1200&auto=format&fit=crop" },
  { id: 5, cat: "acrilico encapsulada", title: "Reversa Dourada", img: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?q=80&w=1200&auto=format&fit=crop" },
  { id: 6, cat: "nailart cores", title: "Efeito Mármore & Folha de Ouro", img: "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?q=80&w=1200&auto=format&fit=crop" }
];

let cart = [];
let currentLightboxIndex = 0;
let currentGalleryList = [...GALLERY_DATA];

function showToast(msg) {
  try {
    const t = $("#toastMessage");
    if (!t) return;
    t.textContent = msg;
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), 2800);
  } catch (e) {}
}

function openCartDrawer() {
  const drawer = $("#cartDrawer");
  if (drawer) drawer.classList.add("open");
}

function closeCartDrawer() {
  const drawer = $("#cartDrawer");
  if (drawer) drawer.classList.remove("open");
}

function navigateTo(pageId) {
  const targetSec = $(`section[data-page="${pageId}"]`);
  if (!targetSec) return;
  $$(".page-section").forEach(s => s.classList.remove("active"));
  targetSec.classList.add("active");
  $$(".nav-link").forEach(l => {
    if (l.getAttribute("data-target") === pageId) l.classList.add("active");
    else l.classList.remove("active");
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
  const mm = $("#mobileMenu");
  if (mm) mm.classList.remove("open");
}

function initNavigation() {
  try {
    document.addEventListener("click", e => {
      const link = e.target.closest("[data-target]");
      if (link) {
        e.preventDefault();
        const p = link.getAttribute("data-target");
        if (p) {
          try { history.pushState(null, "", `#${p}`); } catch (err) { location.hash = `#${p}`; }
          navigateTo(p);
        }
      }
    });

    window.addEventListener("popstate", () => {
      const hash = location.hash.replace("#", "") || "inicio";
      navigateTo(hash);
    });

    const initial = location.hash.replace("#", "") || "inicio";
    navigateTo(initial);

    const mToggle = $("#mobileMenuBtn");
    if (mToggle) {
      mToggle.addEventListener("click", () => {
        const mm = $("#mobileMenu");
        if (mm) mm.classList.toggle("open");
      });
    }
  } catch (e) {}
}

function initTheme() {
  try {
    const btn = $("#themeToggle");
    let isLight = false;
    try { isLight = localStorage.getItem("li_theme") === "light"; } catch (err) {}
    if (isLight) document.documentElement.setAttribute("data-theme", "light");

    if (btn) {
      btn.addEventListener("click", () => {
        const cur = document.documentElement.getAttribute("data-theme");
        const next = cur === "light" ? "dark" : "light";
        if (next === "light") document.documentElement.setAttribute("data-theme", "light");
        else document.documentElement.removeAttribute("data-theme");
        try { localStorage.setItem("li_theme", next); } catch (err) {}
        showToast(next === "light" ? "Modo claro ativado" : "Modo escuro ativado");
      });
    }
  } catch (e) {}
}

function initServices() {
  try {
    const container = $("#servicesContainer");
    const searchInput = $("#serviceSearch");
    let activeCat = "all";

    function render() {
      if (!container) return;
      const query = (searchInput ? searchInput.value : "").toLowerCase();
      const filtered = SERVICES_DATA.filter(item => {
        const matchCat = activeCat === "all" || item.cat === activeCat;
        const matchQuery = item.name.toLowerCase().includes(query) || item.desc.toLowerCase().includes(query);
        return matchCat && matchQuery;
      });

      if (filtered.length === 0) {
        container.innerHTML = `<div style="grid-column:1/-1;padding:40px;text-align:center;opacity:.6;">Nenhum procedimento encontrado com o termo buscado.</div>`;
        return;
      }

      container.innerHTML = filtered.map(s => `
        <div class="service-item">
          <div>
            <div style="height:180px;overflow:hidden;margin-bottom:16px;border:1px solid var(--line);">
              <img src="${s.img}" alt="${s.name}" style="width:100%;height:100%;object-fit:cover;">
            </div>
            <span style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:var(--primary);">${s.cat}</span>
            <h4 style="font-size:18px;text-transform:uppercase;margin:6px 0;">${s.name}</h4>
            <p style="font-size:13px;opacity:.75;">${s.desc}</p>
          </div>
          <div>
            <div class="service-price">R$ ${s.price.toFixed(2).replace('.', ',')}</div>
            <button class="btn-primary add-cart-btn" data-id="${s.id}" style="width:100%;">Adicionar à Bolsa</button>
          </div>
        </div>
      `).join("");
    }

    render();

    if (searchInput) {
      searchInput.addEventListener("input", render);
    }

    const catBtns = $$("#serviceCatFilter .filter-btn");
    catBtns.forEach(btn => {
      btn.addEventListener("click", () => {
        catBtns.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        activeCat = btn.getAttribute("data-scat") || "all";
        render();
      });
    });
  } catch (e) {}
}

function initCart() {
  try {
    const openBtn = $("#cartOpenBtn");
    const closeBtn = $("#cartCloseBtn");
    const mobileBtn = $("#mobileCartBtn");
    const topbarCartBtn = $("#topbarCartBtn");
    const topbarCartCount = $("#topbarCartCount");
    const listEl = $("#cartItemsList");
    const totalEl = $("#cartTotalPrice");
    const countEl = $("#cartCount");
    const mCountEl = $("#mobileCartCount");

    function updateCartUI() {
      const totalQty = cart.reduce((acc, i) => acc + i.qty, 0);
      const totalPrice = cart.reduce((acc, i) => acc + (i.price * i.qty), 0);

      if (countEl) countEl.textContent = totalQty;
      if (mCountEl) mCountEl.textContent = totalQty;
      if (topbarCartCount) topbarCartCount.textContent = totalQty;
      if (totalEl) totalEl.textContent = `R$ ${totalPrice.toFixed(2).replace('.', ',')}`;

      if (!listEl) return;
      if (cart.length === 0) {
        listEl.innerHTML = `<div style="text-align:center;padding:40px 0;opacity:.6;">Sua bolsa de procedimentos está vazia.</div>`;
        return;
      }

      listEl.innerHTML = cart.map(item => `
        <div class="cart-item">
          <img src="${item.img}" alt="${item.name}">
          <div>
            <strong style="font-size:13px;text-transform:uppercase;">${item.name}</strong>
            <div style="font-size:12px;color:var(--primary);">R$ ${(item.price * item.qty).toFixed(2).replace('.', ',')}</div>
            <div style="display:flex;align-items:center;gap:6px;margin-top:6px;">
              <button class="qty-btn" data-cart-action="dec" data-id="${item.id}">-</button>
              <span style="font-size:12px;font-weight:700;">${item.qty}</span>
              <button class="qty-btn" data-cart-action="inc" data-id="${item.id}">+</button>
            </div>
          </div>
          <button data-cart-action="del" data-id="${item.id}" style="color:var(--primary);font-size:14px;padding:8px;">✕</button>
        </div>
      `).join("");
    }

    function addToCart(serviceId) {
      const item = SERVICES_DATA.find(s => s.id === Number(serviceId));
      if (!item) return;
      const existing = cart.find(c => c.id === item.id);
      if (existing) {
        existing.qty += 1;
      } else {
        cart.push({ ...item, qty: 1 });
      }
      updateCartUI();
      showToast(`${item.name} adicionado à bolsa!`);
    }

    document.addEventListener("click", e => {
      const addBtn = e.target.closest(".add-cart-btn, .add-direct-btn");
      if (addBtn) {
        const id = addBtn.getAttribute("data-id");
        if (id) addToCart(id);
      }

      const cartAct = e.target.closest("[data-cart-action]");
      if (cartAct) {
        const action = cartAct.getAttribute("data-cart-action");
        const id = Number(cartAct.getAttribute("data-id"));
        const item = cart.find(c => c.id === id);
        if (!item) return;

        if (action === "inc") item.qty += 1;
        if (action === "dec") {
          item.qty -= 1;
          if (item.qty <= 0) cart = cart.filter(c => c.id !== id);
        }
        if (action === "del") {
          cart = cart.filter(c => c.id !== id);
        }
        updateCartUI();
      }
    });

    if (openBtn) openBtn.addEventListener("click", () => openCartDrawer());
    if (closeBtn) closeBtn.addEventListener("click", () => closeCartDrawer());
    if (mobileBtn) {
      mobileBtn.addEventListener("click", () => {
        const mm = $("#mobileMenu");
        if (mm) mm.classList.remove("open");
        openCartDrawer();
      });
    }
    if (topbarCartBtn) topbarCartBtn.addEventListener("click", () => openCartDrawer());

    const checkoutBtn = $("#btnCheckoutWhatsApp");
    if (checkoutBtn) {
      checkoutBtn.addEventListener("click", () => {
        if (cart.length === 0) {
          showToast("Adicione procedimentos antes de finalizar!");
          return;
        }

        const name = $("#orderClientName") ? $("#orderClientName").value.trim() : "";
        const payment = $("#orderPaymentMethod") ? $("#orderPaymentMethod").value : "PIX";
        const obs = $("#orderObservations") ? $("#orderObservations").value.trim() : "";

        if (!name) {
          showToast("Informe seu nome para o agendamento.");
          if ($("#orderClientName")) $("#orderClientName").focus();
          return;
        }

        const totalPrice = cart.reduce((acc, i) => acc + (i.price * i.qty), 0);
        let itemsText = cart.map(i => `• ${i.qty}x ${i.name} (R$ ${(i.price * i.qty).toFixed(2)})`).join("\n");

        let msg = `*NOVO PEDIDO DE PROCEDIMENTO - LI UNHA*\n`;
        msg += `*Cliente:* ${name}\n`;
        msg += `*Pagamento:* ${payment}\n`;
        if (obs) msg += `*Observação/Data:* ${obs}\n`;
        msg += `\n*Procedimentos Selecionados:*\n${itemsText}\n`;
        msg += `\n*Total Estimado:* R$ ${totalPrice.toFixed(2).replace('.', ',')}\n`;
        msg += `\n_Local:_ Av. Nossa Sra. de Copacabana, 330 - Sl 903`;

        const waUrl = `https://wa.me/5521965902390?text=${encodeURIComponent(msg)}`;
        window.open(waUrl, "_blank");
      });
    }

    updateCartUI();
  } catch (e) {}
}

function initGallery() {
  try {
    const homeGrid = $("#homeGalleryGrid");
    const fullGrid = $("#fullGalleryGrid");

    function renderGrids() {
      if (homeGrid) {
        homeGrid.innerHTML = GALLERY_DATA.slice(0, 4).map((g, idx) => `
          <div class="visual-card lb-trigger" data-index="${idx}">
            <img src="${g.img}" alt="${g.title}">
            <div class="visual-overlay">
              <h4>${g.title}</h4>
              <p>Copacabana Studio</p>
            </div>
          </div>
        `).join("");
      }

      if (fullGrid) {
        fullGrid.innerHTML = currentGalleryList.map((g, idx) => `
          <div class="visual-card lb-trigger" data-index="${idx}">
            <img src="${g.img}" alt="${g.title}">
            <div class="visual-overlay">
              <h4>${g.title}</h4>
              <p>Ver em alta definição</p>
            </div>
          </div>
        `).join("");
      }
    }

    renderGrids();

    $$(".cat-filters .filter-btn[data-cat]").forEach(b => {
      b.addEventListener("click", () => {
        $$(".cat-filters .filter-btn[data-cat]").forEach(btn => btn.classList.remove("active"));
        b.classList.add("active");
        const c = b.getAttribute("data-cat");
        const filtered = c === "all" ? GALLERY_DATA : GALLERY_DATA.filter(item => item.cat.includes(c));
        if (homeGrid) {
          homeGrid.innerHTML = filtered.map((g, idx) => `
            <div class="visual-card lb-trigger" data-index="${idx}">
              <img src="${g.img}" alt="${g.title}">
              <div class="visual-overlay">
                <h4>${g.title}</h4>
                <p>Copacabana Studio</p>
              </div>
            </div>
          `).join("");
        }
      });
    });

    $$(".cat-filters .filter-btn[data-gcat]").forEach(b => {
      b.addEventListener("click", () => {
        $$(".cat-filters .filter-btn[data-gcat]").forEach(btn => btn.classList.remove("active"));
        b.classList.add("active");
        const gc = b.getAttribute("data-gcat");
        currentGalleryList = gc === "all" ? GALLERY_DATA : GALLERY_DATA.filter(item => item.cat.includes(gc));
        renderGrids();
      });
    });

    const lbModal = $("#lightboxModal");
    const lbImg = $("#lbImg");
    const lbClose = $("#lbClose");
    const lbPrev = $("#lbPrev");
    const lbNext = $("#lbNext");

    function openLightbox(index) {
      currentLightboxIndex = index;
      if (lbImg && GALLERY_DATA[index]) {
        lbImg.src = GALLERY_DATA[index].img;
        if (lbModal) lbModal.classList.add("open");
      }
    }

    function closeLightbox() {
      if (lbModal) lbModal.classList.remove("open");
    }

    function nextLb() {
      currentLightboxIndex = (currentLightboxIndex + 1) % GALLERY_DATA.length;
      openLightbox(currentLightboxIndex);
    }

    function prevLb() {
      currentLightboxIndex = (currentLightboxIndex - 1 + GALLERY_DATA.length) % GALLERY_DATA.length;
      openLightbox(currentLightboxIndex);
    }

    document.addEventListener("click", e => {
      const card = e.target.closest(".lb-trigger");
      if (card) {
        const idx = Number(card.getAttribute("data-index") || 0);
        openLightbox(idx);
      }
    });

    if (lbClose) lbClose.addEventListener("click", closeLightbox);
    if (lbNext) lbNext.addEventListener("click", nextLb);
    if (lbPrev) lbPrev.addEventListener("click", prevLb);

    window.addEventListener("keydown", e => {
      if (!lbModal || !lbModal.classList.contains("open")) return;
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowRight") nextLb();
      if (e.key === "ArrowLeft") prevLb();
    });
  } catch (e) {}
}

function initAccordion() {
  try {
    $$(".accordion-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const parent = btn.parentElement;
        if (!parent) return;
        const isActive = parent.classList.contains("active");
        $$(".accordion-item").forEach(i => i.classList.remove("active"));
        if (!isActive) parent.classList.add("active");
      });
    });
  } catch (e) {}
}

function initForm() {
  try {
    const form = $("#appointmentForm");
    if (!form) return;
    form.addEventListener("submit", e => {
      e.preventDefault();
      const name = $("#appoName") ? $("#appoName").value.trim() : "";
      const service = $("#appoService") ? $("#appoService").value : "";
      const date = $("#appoDate") ? $("#appoDate").value : "";
      const time = $("#appoTime") ? $("#appoTime").value : "";
      const notes = $("#appoNotes") ? $("#appoNotes").value.trim() : "";

      let msg = `*SOLICITAÇÃO DE AGENDAMENTO - LI UNHA*\n`;
      msg += `*Nome:* ${name}\n`;
      msg += `*Procedimento:* ${service}\n`;
      msg += `*Data Sugerida:* ${date}\n`;
      msg += `*Turno:* ${time}\n`;
      if (notes) msg += `*Observações:* ${notes}\n`;
      msg += `\n_Endereço do Salão:_ Av. Nossa Sra. de Copacabana, 330 - Sl 903`;

      const waUrl = `https://wa.me/5521965902390?text=${encodeURIComponent(msg)}`;
      window.open(waUrl, "_blank");
      showToast("Direcionando ao WhatsApp...");
    });
  } catch (e) {}
}

function initModals() {
  try {
    const pBtn = $("#btnProfile");
    const pModal = $("#profileModal");
    const pClose = $("#profileCloseBtn");
    const saveProf = $("#btnSaveProfile");
    const profInput = $("#profileInputName");
    const addStampBtn = $("#btnAddStamp");
    const resetStampBtn = $("#btnResetStamp");
    const stampCountEl = $("#profileStampCount");
    const progressFillEl = $("#profileProgressFill");
    const stampMsgEl = $("#profileStampMessage");
    const tierTextEl = $("#profileTierText");

    let stamps = 6;
    try {
      const storedStamps = localStorage.getItem("li_user_stamps");
      if (storedStamps !== null) stamps = parseInt(storedStamps, 10) || 0;
    } catch (err) {}

    function updateStampsUI() {
      const maxStamps = 10;
      const pct = Math.min(100, Math.round((stamps / maxStamps) * 100));
      if (stampCountEl) stampCountEl.textContent = `${stamps} / ${maxStamps} Selos`;
      if (progressFillEl) progressFillEl.style.width = `${pct}%`;
      if (tierTextEl) {
        if (stamps >= 10) tierTextEl.textContent = "Nível Atual: VIP Ouro ✦";
        else if (stamps >= 5) tierTextEl.textContent = "Nível Atual: VIP Prata";
        else tierTextEl.textContent = "Nível Atual: VIP Bronze";
      }
      if (stampMsgEl) {
        if (stamps >= 10) {
          stampMsgEl.innerHTML = "🎉 <strong>Parabéns!</strong> Você já tem direito ao seu <strong>Spa das Mãos + Nail Art Cortesia</strong>!";
        } else {
          const diff = maxStamps - stamps;
          stampMsgEl.innerHTML = `Faltam ${diff} manutenç${diff === 1 ? 'ão' : 'ões'} para você ganhar um <strong>Spa das Mãos + Nail Art Cortesia</strong>!`;
        }
      }
    }

    updateStampsUI();

    if (pBtn && pModal) pBtn.addEventListener("click", () => pModal.classList.add("open"));
    if (pClose && pModal) pClose.addEventListener("click", () => pModal.classList.remove("open"));

    if (addStampBtn) {
      addStampBtn.addEventListener("click", () => {
        stamps = Math.min(10, stamps + 1);
        try { localStorage.setItem("li_user_stamps", stamps); } catch (e) {}
        updateStampsUI();
        showToast(stamps === 10 ? "Recompensa desbloqueada!" : "+1 Selo de Manutenção registrado!");
      });
    }

    if (resetStampBtn) {
      resetStampBtn.addEventListener("click", () => {
        stamps = 0;
        try { localStorage.setItem("li_user_stamps", 0); } catch (e) {}
        updateStampsUI();
        showToast("Cartão de selos reiniciado.");
      });
    }

    try {
      const savedName = localStorage.getItem("li_user_name");
      if (savedName && profInput) profInput.value = savedName;
    } catch (err) {}

    if (saveProf && profInput) {
      saveProf.addEventListener("click", () => {
        const val = profInput.value.trim();
        try { localStorage.setItem("li_user_name", val); } catch (err) {}
        showToast(val ? `Olá, ${val}! Perfil salvo.` : "Perfil atualizado!");
        if (pModal) pModal.classList.remove("open");
      });
    }

    const nBtn = $("#btnNotif");
    const nModal = $("#notifModal");
    const nClose = $("#notifCloseBtn");
    const notifDot = $("#notifDot");
    const markReadBtn = $("#btnMarkNotifRead");

    if (nBtn && nModal) {
      nBtn.addEventListener("click", () => {
        nModal.classList.add("open");
        if (notifDot) notifDot.style.display = "none";
      });
    }
    if (nClose && nModal) nClose.addEventListener("click", () => nModal.classList.remove("open"));

    if (markReadBtn) {
      markReadBtn.addEventListener("click", () => {
        if (notifDot) notifDot.style.display = "none";
        showToast("Avisos marcados como lidos.");
        if (nModal) nModal.classList.remove("open");
      });
    }

    const onModal = $("#onboardingModal");
    const onBtn = $("#onboardingStartBtn");
    let hasSeen = false;
    try { hasSeen = localStorage.getItem("li_onboarding_seen") === "true"; } catch (err) {}

    if (!hasSeen && onModal) {
      setTimeout(() => onModal.classList.add("open"), 800);
    }

    if (onBtn && onModal) {
      onBtn.addEventListener("click", () => {
        onModal.classList.remove("open");
        try { localStorage.setItem("li_onboarding_seen", "true"); } catch (err) {}
        navigateTo("servicos");
      });
    }
  } catch (e) {}
}

function startApp() {
  initNavigation();
  initTheme();
  initServices();
  initCart();
  initGallery();
  initAccordion();
  initForm();
  initModals();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startApp);
} else {
  startApp();
}
